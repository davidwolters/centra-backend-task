<?php
require_once __DIR__ . '/../../vendor/autoload.php';


use KanbanBoard\Controllers\GithubAPIController;
use KanbanBoard\Controllers\ViewController;
use KanbanBoard\Utilities\ArrayUtilities;
use KanbanBoard\Utilities\EnvLoader;

use Dotenv\Dotenv;

// Load .env file
$dotenvPath = __DIR__ . "/../../";
$dotenv = Dotenv::createImmutable($dotenvPath);
$dotenv->load();

// Load required environment values.
$dotenv->required(['GH_REPOSITORIES', 'GH_ACCOUNT', 'GH_CLIENT_ID', 'GH_CLIENT_SECRET']);
$envLoader = new EnvLoader( $_ENV );
$repositoryList = $envLoader->env( 'GH_REPOSITORIES' );
$account = $envLoader->env('GH_ACCOUNT');

$repositories = explode('|', $repositoryList); 


$cacheDir = __DIR__ . '/../../../tmp/github-api-cache';
$github = new GithubAPIController($account, $cacheDir);
$board = new ViewController($github, $repositories, array('waiting-for-feedback'));
$data = $board->board();

$m = new Mustache_Engine(array(
	'loader' => new Mustache_Loader_FilesystemLoader(__DIR__ . '/../views'),
));


echo $m->render('index', array('milestones' => array_values($data)));