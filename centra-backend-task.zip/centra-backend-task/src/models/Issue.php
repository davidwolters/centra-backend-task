<?php

namespace KanbanBoard\Models;
use KanbanBoard\Utilities\ArrayUtilities;

/**
 * Issue model class.
 * Represents a single Issue, has no side effects.
 */
class Issue
{

	/**
	 * @var int	QUEUED	State for queued issues.	
	 */
	const QUEUED = 0;

	/**
	 * @var int ACTIVE	State for the active issues
	 */
	const ACTIVE = 1;

	/**
	 * @var int CLOSED	State for the closed issues.
	 */
	const CLOSED = 2; 

	/**
	 * @var string $id	The ID of the issue.
	 */
	private string $id;
	
	/**
	 * @var string $name The title of the issue
	 */
	private string $name;
	
	/**
	 * @var string $url	The url to the issue in github.
	 */
	private string $url;


	/**
	 * @var array $labels 	A list of labels attatched to this issue.
	 */
	private array $labels;

	/**
	 * @var string|null $assigneeImage	The image of the person assigned to this issue
	 */
	private ?string $assigneeImage; 

	/**
	 * @var int	$state	The state of this issue, one of QUEUED, ACTIVE or CLOSED.
	 */
	private int $state;

	/**
	 * @var array $pausedLabels	A list of which labels are considered paused labels
	 */
	private array $pausedLabels; 

	/**
	 * Constructor for Issue model class.
	 * @param string $id					The ID of the issue.
	 * @param string $name					The title of the issue.
	 * @param string $url					The URL to the issue.
	 * @param array $labels					A list of labels attached to this issue.
	 * @param string|null $assigneeImage	Optional, if issue has assignee, the profile pic of that assignee.
	 * @param string $state					The state of this issue.
	 * @param array $pausedLabels			The labels which consider this issue to be paused.
	 */
	public function __construct(string $id, string $name, string $url, array $labels, ?string $assigneeImage, string $state, array $pausedLabels )
	{
		$this->id = $id;
		$this->name = $name;
		$this->url = $url;
		$this->labels = $labels;
		$this->assigneeImage = $assigneeImage;
		$this->state = $state;
		$this->pausedLabels = $pausedLabels;
	}

	/**
	 * Creates an Issue object from data from an array. (from API).
	 * @param mixed $data			The data given.
	 * @param mixed $pausedLabels	The labels which consider this issue to be QUEUED.
	 * 
	 * @return Issue				An new Issue model. 
	 */
	public static function fromData($data, $pausedLabels) 
	{
		if (!is_array($data)) return null;
		if ( !ArrayUtilities::hasValue($data, 'id' ) ) return null; 
		if ( !ArrayUtilities::hasValue($data, 'title' ) ) return null; 
		if ( !ArrayUtilities::hasValue($data, 'html_url' ) ) return null; 
		if ( !ArrayUtilities::hasValue($data, 'state' ) ) return null; 

		if ( !ArrayUtilities::hasValue($data, 'labels' ) ) $data['labels'] = []; 

		$hasAssignee = ArrayUtilities::hasValue( $data, 'assignee' );

		$assigneeImage = $hasAssignee ? $data['assignee']['avatar_url'] . '?s=16' : null;

		// Get the state, if it is closed assigne CLOSED, if we have an assigne it is either ACTIVE or QUEUED.
		$state = $data['state'] === 'closed' ? self::CLOSED : (
			$hasAssignee ? self::ACTIVE : self::QUEUED
		);

		return new self(
			$data['id'], 
			$data['title'], 
			$data['html_url'], 
			$data['labels'], 
			$assigneeImage, 
			$state, 
			$pausedLabels
		);
	}
	

	/**
	 * Getter for $name.
	 * @return string	The issue name.
	 */
	public function name(): string
	{
		return $this->name;
	}

	/**
	 * Getter for url.
	 * @return string	The url.
	 */
	public function url(): string
	{
		return $this->url;
	}

	/**
	 * Returns all labels that are paused.
	 * @return array	All labels that match $pausedLabels
	 */
	public function pausedLabels(): array
	{
		return array_filter($this->labels, function($label) {
			return in_array($label, $this->pausedLabels);
		}); 
	}

	/**
	 * Is this issue paused?
	 * @return bool		If this issue is paused or not.
	 */
	public function paused(): bool
	{
		return count($this->pausedLabels()) > 0;
	} 
       
	/**
	 * Getter for $assigneeImage
	 * @return string	The assigneeImage.
	 */
	public function assigneeImage(): string
	{
		return $this->assigneeImage;
	}

	/**
	 * Getter for $state.
	 * @return int	The issue's state.
	 */
	public function state(): int
	{
		return $this->state;
	}

}