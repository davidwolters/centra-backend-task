<?php

namespace KanbanBoard\Models;
use KanbanBoard\Utilities\ArrayUtilities;

/**
 * Milestone model. Model object for a milestone, which contains a list of issues. 
 */
class Milestone 
{
	/**
	 * @var string $id	The id of the milestone.
	 */
	private string $id;

	/**
	 * @var string $name	The name of the milestone.
	 */
	private string $name;

	/**
	 * @var string $url		The url to the milestone.
	 */
	private string $url;

	/**
	 * @var array $issues	A list of issues for this milestone.
	 */
	private array $issues;

	/**
	 * @var string $repository	The repository for this milestone
	 */
	private string $repository;

	/**
	 * Constructor for Milestone.
	 * @param string $id			The ID of the milestone.
	 * @param string $name			The title of the milestone.
	 * @param string $url			The URL to the milestone.
	 * @param string $repository	The repository of this milestone.
	 */
	public function __construct(string $id, string $name, string $url, string $repository)
	{
		$this->id = $id;
		$this->name = $name;
		$this->url = $url;
		$this->repository = $repository;
	}


	/**
	 * Creates a milestone from data (from an API).
	 * @param array $data			The data provided.
	 * @param string $repository	The repository for this milestone.
	 * 
	 * @return Milestone|null		A new Milestone instance.
	 */
	public static function fromData(array $data, string $repository): ?Milestone
	{
		if (!ArrayUtilities::hasValue($data, 'number')) return null;
		if (!ArrayUtilities::hasValue($data, 'title')) return null;
		if (!ArrayUtilities::hasValue($data, 'url')) return null;

		return new self($data['number'], $data['title'], $data['url'], $repository);
	}


	/**
	 * @return bool	Does this milestone have any progress?
	 */
	public function hasProgress(): bool
	{
		return array_reduce( $this->issues, function( $acc, $curr) {
			return $acc + ( is_array($curr) ? count($curr) : 0); 
		}, 0) > 0;
	}

	/**
	 * Returns percent completion of this milestone.
	 * @return int	The percentage completion of this milestone
	 */
	public function percent(): int 
	{
		if (!is_array($this->issues) or !$this->hasProgress()) return 0;
		if (!ArrayUtilities::hasValue($this->issues, Issue::CLOSED) and 
			!ArrayUtilities::hasValue($this->issues, Issue::ACTIVE)) return 0;

		$closed = ArrayUtilities::count($this->issues, Issue::CLOSED);
		$active = ArrayUtilities::count($this->issues, Issue::ACTIVE);
		$queued = ArrayUtilities::count($this->issues, Issue::QUEUED);

		$total = $closed + $active + $queued;
		return round(($closed / $total) * 100);
	}

	/**
	 * Getter for $id.
	 * @return string	The ID of this milestone.
	 */
	public function id(): string 
	{
		return $this->id;
	}

	/**
	 * Getter for $name.
	 * @return string	The title of this milestone.
	 */
	public function name(): string 
	{
		return $this->name;
	}

	/**
	 * Getter for $url.
	 * @return string	The URL to this milestone.
	 */
	public function url(): string
	{
		return $this->url;
	}
	
	/**
	 * Getter for repository.
	 * @return string	The repository for this milestone.
	 */
	public function repository(): string
	{
		return $this->repository;
	}

	/**
	 * Getter for issues.
	 * @return array	The issues for this milestone.
	 */
	public function issues(): array
	{
		return $this->issues;
	}

	/**
	 * Getter for closed issues on this milestone.
	 * @return array|null	The closed issues on this milestone.
	 */
	public function closedIssues(): ?array 
	{
		return $this->issues[Issue::CLOSED] ?? null;
	}

	/**
	 * Gets the paused issues on this milestone.
	 * @return array|null	The paused issues.
	 */
	public function pausedIssues(): ?array 
	{
		return array_filter( $this->issues, function( $issue ) {
			return $issue->paused();
		} );	
	}

	/**
	 * Getter for the queued issues on this milestone.
	 * @return array|null	The queued issues.
	 */
	public function queuedIssues(): ?array
	{
		return $this->issues[Issue::QUEUED] ?? null;
	}

	/**
	 * Getter for the active issues on this milestone.
	 * @return array|null
	 */
	public function activeIssues(): ?array 
	{
		return $this->issues[Issue::ACTIVE] ?? null;
	}

	/**
	 * Getter for the amount of closed issues on this milestone.
	 * @return int|null	 The number of closed issues.
	 */
	public function numClosed(): int 
	{
		return ArrayUtilities::count($this->issues, Issue::CLOSED);	
	}

	/**
	 * Getter for the amount of active issues on this milestone.
	 */
	public function numActive(): int 
	{
		return ArrayUtilities::count($this->issues, Issue::ACTIVE);	
	}

	/**
	 * Getter for number of queued issues.
	 * @return int	Number of queued issues.
	 */
	public function numQueued(): int
	{
		return ArrayUtilities::count($this->issues, Issue::QUEUED);	
	}

	/**
	 * Setter for issues.
	 * @param array $issues		An array of Issue model objects.
	 */
	public function setIssues(array $issues) 
	{
		$this->issues = $issues;
	}

}
