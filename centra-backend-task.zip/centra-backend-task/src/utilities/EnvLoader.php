<?php

namespace KanbanBoard\Utilities;

/**
 * Retrieves env variables. 
 */
class EnvLoader {

    /**
     * @var array $envSource 	The array where the ENV variables are stored, in prod this is $_ENV
     */
    private array $envSource;

    /**
	 * Constructor
     * @param array $envSource	 The array where ENV variables are stored.
     */
    public function __construct( array $envSource ) {
        $this->envSource = $envSource;
    }

	/**
	 * Retrieves an env variable from the array.
	 * @param string $name	The name of the variable.
	 * @param null $default	A default value.
	 * 
	 * @return mixed  The variable if it exists, otherwise default if it is set or null if not. 
	 */
	public function env(string $name, $default = null) {
		$value = $this->envSource[$name];

		if(isset($defaul)) return empty( $value ) ? $default : $value; 
		
		return empty( $value ) ? null : $value; 
	}

}