<?php
namespace KanbanBoard\Utilities;

/**
 * Utility class operating on arrays.
 */
class ArrayUtilities
{

	
	/**
	 * Checks if an array has a key that is nonempty and not null.
	 * @param mixed $array	The array.
	 * @param mixed $key	The key.
	 * 
	 * @return bool	If the array has that value.
	 */
	public static function hasValue($array, $key) {
		return is_array($array) && array_key_exists($key, $array) && !empty($array[$key]);
	}

	/**
	 * Checks if an array has multiple keys that are nonempty and not null.
	 * @param mixed $array		The array.
	 * @param mixed ...$keys	The keys
	 * 
	 * @return	bool	If all keys correspond to existing values in that array. 
	 */
	public static function hasValues($array, ...$keys) 
	{
		return count(
			array_filter( $keys, function ($key) use ($array) {
				return !self::hasValue($array, $key);
			} )
		) === 0;
	}

	/**
	 * Returns how many items are in an array's child-array.
	 * @param array $array	The array
	 * @param mixed $key	The key, which should correspond to an array to be counted
	 * 
	 * @return	int How many items the child array has.	
	 */
	public static function count(array $array, $key ) {
		 return self::hasValue($array, $key) and is_array($array[$key]) ? count($array[$key]) : 0;
	}

	/**
	 * Dumps a variable inside of <pre>tags</pre>
	 * @param mixed $data	The data to dump.
	 */
	public static function dump($data) {
		echo '<pre>';
		var_dump($data);
		echo '</pre>';
	}
}