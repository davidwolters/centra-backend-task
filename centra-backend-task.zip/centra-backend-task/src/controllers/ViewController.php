<?php
namespace KanbanBoard\Controllers;

use KanbanBoard\Controllers\APIControllerInterface;
use KanbanBoard\Models\Issue;
use KanbanBoard\Models\Milestone;
use KanbanBoard\Utilities\ArrayUtilities;

/**
 * ViewController, main controller class for the application.
 * Handles fetching data from the APIController, and sorting that data into Model 
 * objects to be passed to the view. 
 */
class ViewController {

	/**
	 * @var APIController $github	Reference to the APIController for fetching milestones and issues.
	 */
	private APIControllerInterface $github;

	/**
	 * @var array $repositories		Array of repositories to get milestones from.
	 */
	private array $repositories;

	private array $pausedLabels;
	
	/**
	 * @param APIController $github 	APIController for access to fetching milestones and issues
	 * @param array $repositories		Array of strings containging names of repositories
	 * @param array $pausedLabels		List of strings, labels which if a card has them, is considered "paused"
	 */
	public function __construct(APIControllerInterface $github, array $repositories, array $pausedLabels = [] )
	{
		$this->github = $github;
		$this->repositories = $repositories;
		$this->pausedLabels = $pausedLabels;
	}

	/**
	 * @return array A model for the view, containing all milestones and their issues
	 */
	public function board(): array 
	{
		// Fetch the milestones.
		$milestones = $this->milestones();

		// Set issues for each milestone.
		array_walk( $milestones, [$this, 'setIssuesForMilestone'] );
	
		// Sort the milestones.
		$milestones = $this->sortMilestones($milestones);

		return $milestones;
	}

	/**
	 * Retrieves milestones from API, and converts them to Milestone objects.
	 * @return array	Array of milestones. 
	 */
	private function milestones() 
	{
		// Create an array of milestones from one or more repositories.
		return array_reduce( $this->repositories, function ($result, $repo) {

			// Get the milestone data for this repository.
			$milestoneData = $this->github->milestones($repo);

			// Function to convert each milestone array entry to a Milestone object.
			$dataToMilestone = function($data) use ($repo) {
				return Milestone::fromData($data, $repo);	
			};

			// Turn each milestone data to an object.
			$repoMilestones = array_map( $dataToMilestone, $milestoneData );

			// Add it to the results array.
			$result = [...$result, ...$repoMilestones];
			return $result;
		}, []);
	}

	/**
	 * Fetches, and sets issues for a specific milestone.
	 * 
	 * @param Milestone $milestone 	The milestone to fetch issues for.
	 */
	private function setIssuesForMilestone( Milestone $milestone ) 
	{
		$issues = $this->issues( $milestone->repository(), $milestone->id() );
		$milestone->setIssues($issues);
	}

	/**
	 * Sorts an array of milestones by name.
	 * @param array|null $milestones	An array of milestones
	 * 
	 * @return	array 					The array, but sorted by name.
	 */
	private function sortMilestones(?array $milestones) 
	{
		usort( $milestones, function ($milestoneA, $milestoneB) {
			return strcmp($milestoneA->name(), $milestoneB->name());
		});

		return $milestones;
	}

	/**
	 * Retrieves all issues for a milestone, and returns those issues as sorted Issue objects.
	 * @param string $repository	The repository to fetch the issues from
	 * @param string $milestoneID	The ID of the issue to fetch the issues from.
	 * 
	 * @return array				The issues for that repository and milestone.
	 */
	private function issues(string $repository, string $milestoneID): array
	{
		// Fetch the issues for this milestone.
		$issueData = $this->github->issues($repository, $milestoneID);

		// Filter the issues, and get the Issue objects from the filtered data.
		$issues = $this->issuesFromData(
			$this->filterMilestoneIssues( $issueData )
		);

		// If we have active issues, lets sort them by if, and how many paused labels they have.
		if ( ArrayUtilities::hasValue( $issues, Issue::ACTIVE)) {
			$issues[Issue::ACTIVE] = $this->sortIssuesByPausedLabels($issues[Issue::ACTIVE]);
		}
		
		return $issues;
	}
	
	/**
	 * Converts an array of data from an API to an associoative array of state => Issue objects.
	 * @param array $data	The data to be converted into Issue objects.	
	 * 
	 * @return array	Associoative array containing state (Issue constant) => Issue
	 */
	private function issuesFromData(array $data): array {
		return array_reduce( $data, function ($acc, $issueData) {
			$issue = Issue::fromData($issueData, $this->pausedLabels);
			$acc[$issue->state()][] = $issue;
			return $acc;
		}, [] );
	}

	/**
	 * Filters milestone issue data, and makes sure that no pull requests are included as issues.
	 * @param array $issues		The issue data.
	 * 
	 * @return array			The filtered issue data.
	 */
	private function filterMilestoneIssues(array $issues): array {
		return array_filter( $issues, function($issue) {
			return !ArrayUtilities::hasValue($issue, 'pull_request');
		});
	}

	/**
	 * Sorts issues either by number of labels matching $this->pausedLabels, or by name if paused labels
	 * are the same.
	 * @param array|null $issues	An array of Issue objects.
	 * 
	 * @return array				The sorted Issue objects. 
	 */
	private function sortIssuesByPausedLabels(?array $issues) {
		if ( !isset( $issues ) or !is_array( $issues ) ) return []; 

		usort( $issues, function( $issueA, $issueB ) {
			$aPaused = count( $issueA->pausedLabels() );
			$bPaused = count( $issueB->pausedLabels() );

			// If both have the same number of paused lables, compare names, otherwise sort by number of paused lables (DESC).
			return $aPaused === $bPaused ? strcmp($issueA->name(), $issueB->name()) : $aPaused <=> $bPaused;
		});

		return $issues;
	}
}
