<?php
namespace KanbanBoard\Controllers;

use KanbanBoard\Controllers\APIControllerInterface;
use Github\Client;
use Github\HttpClient\CachedHttpClient;

/**
 * Implementation of APIController, this
 * APIController accesses the Github API via KnpLabs/php-github-api.
 */
class GithubAPIController implements APIControllerInterface
{

	/**
	 * @var string $account The name of the account we are fetching data from. Set as an .env variable.
	 */
	private string $account;

	/**
	 * @var \Github\Api\Issue\Milestones $milestoneAPI    Reference to the milestone API.
	 */
	private \Github\Api\Issue\Milestones $milestoneAPI;

	/**
	 * @var \Github\Api\Issue $issueAPI		Reference to the issue API.
	 */
	private \Github\Api\Issue $issueAPI;

	
	/**
	 * Constructor, creates a new instance of GithubAPIController and initializes the APIs.
	 * @param string $account   The name of the account where we are fetching the milestones from.
	 * @param string $cacheDir  The path to the cache directory.
	 */
	public function __construct(string $account, string $cacheDir)
	{
		// Create a cached HTTP client.
		$cachedHttpClient = new \Github\HttpClient\CachedHttpClient(['cache_dir' => $cacheDir]);

		// Use it to create the main client.
		$client = new \Github\Client($cachedHttpClient);

		// Get the milestone, and issue APis.
		$this->milestoneAPI = $client->api('issues')->milestones();
		$this->issueAPI = $client->api('issue');

		$this->account = $account;
	}

	
	/**
	 * Retrieves all milestone for a repository.
	 * @param string $repository	Name of the repository.
	 * 
	 * @return array|null			The data from the response, or null if the repository is invalid.
	 */
	public function milestones(string $repository): ?array 
	{
		return $this->milestoneAPI->all($this->account, $repository);
	}

	/**
	 * Retrives all issues for a repository and a milestone.
	 * @param string $repository	The name of the repository.
	 * @param string $milestoneID	The ID of the milestone.
	 * 
	 * @return array|null			The data from the response or null if the milestone ID or repository is invalid.
	 */
	public function issues(string $repository, string $milestoneID): ?array
	{
		$issueParameters = ['milestone' => $milestoneID, 'state' => 'all'];
		return $this->issueAPI->all($this->account, $repository, $issueParameters);
	}
}