<?php

namespace KanbanBoard\Controllers;

/**
 * Interface for APIController. Includes methods for retrieving issues and milestones.
 */
interface APIControllerInterface {
	/**
	 * Retrieves all milestone from a repository.
	 * @param string $repository The name of the repository.
	 * 
	 * @return array|null       The milestones for that repository. 
	 */
	public function milestones(string $repository): ?array;

	/**
	 * Retrieves all issues from a repository and milestone.
	 * @param string $repository    The name of the repository.
	 * @param string $milestoneID   The ID of the milestone.
	 * 
	 * @return array|null           The milestones for that repository.
	 */
	public function issues(string $repository, string $milestoneID): ?array;
}