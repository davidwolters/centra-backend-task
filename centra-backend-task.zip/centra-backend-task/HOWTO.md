# How to get this project up and running from your local machine

- Get a development environment. For the development of this, i used valet, however I do not recommend this as it requires you to write your own driver to redirect the requests from / to /src/public. 
    - Minimum php verision, 7.4
    - Composer needs to be installed
- Configure .htaccess to internally redirect all requests to src/public
- Install dependencies via php composer.phar install
- Generate the autoload via php composer.phar dump-autoload
- Create a .env in the project root, and fill in the following ENV-variables:
    - GH_REPOSITORIES (this is a | separated list of repository names, excluding name of repo owners)
    - GH_ACCOUNT 
- Now you should be up and running, simply visit localhost, or wherever you put the directory and you should see the kanbanboard!